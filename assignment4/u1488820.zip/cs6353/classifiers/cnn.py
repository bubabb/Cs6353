#cnn.py

import numpy as np
from cs6353.layers import *
from cs6353.fast_layers import *
from cs6353.layer_utils import *

class ThreeLayerConvNet(object):
    def __init__(self, input_dim=(3, 32, 32), num_filters=32, filter_size=7,
                 hidden_dim=100, num_classes=10, weight_scale=1e-3, reg=0.0,
                 dtype=np.float32):
        self.params = {}
        self.reg = reg
        self.dtype = dtype

        # Convolutional layer
        self.params['W1'] = np.random.normal(0, weight_scale, (num_filters, input_dim[0], filter_size, filter_size))
        self.params['b1'] = np.zeros(num_filters)

        # Calculate output dimensions using a helper function
        conv_out_height, conv_out_width = self.compute_output_dim(input_dim[1], input_dim[2], filter_size, 1, 1)
        pool_out_height, pool_out_width = self.compute_output_dim(conv_out_height, conv_out_width, 2, 2, 2)

        # Compute flattened size dynamically after pooling
        flattened_size = num_filters * pool_out_height * pool_out_width

        # Initialize weights for the fully connected layers
        self.params['W2'] = np.random.normal(0, weight_scale, (flattened_size, hidden_dim))
        self.params['b2'] = np.zeros(hidden_dim)

        self.params['W3'] = np.random.normal(0, weight_scale, (hidden_dim, num_classes))
        self.params['b3'] = np.zeros(num_classes)

        for k, v in self.params.items():
            self.params[k] = v.astype(dtype)

    def compute_output_dim(self, H, W, filter_size, stride, padding):
        out_height = (H + 2 * padding - filter_size) // stride + 1
        out_width = (W + 2 * padding - filter_size) // stride + 1
        return out_height, out_width

    def loss(self, X, y=None):
        W1, b1 = self.params['W1'], self.params['b1']
        W2, b2 = self.params['W2'], self.params['b2']
        W3, b3 = self.params['W3'], self.params['b3']

        filter_size = W1.shape[2]
        conv_param = {'stride': 1, 'pad': int((filter_size - 1) / 2)}
        pool_param = {'pool_height': 2, 'pool_width': 2, 'stride': 2}

        scores = None

        # Forward pass: Convolutional layer
        out_conv, conv_cache = conv_forward_fast(X, W1, b1, conv_param)

        # ReLU activation
        out_relu, relu_cache = relu_forward(out_conv)

        # Max-pooling
        out_pool, pool_cache = max_pool_forward_fast(out_relu, pool_param)

        print("Shape of out_pool before flattening:", out_pool.shape)  # Debug print

        # Flatten the pooled output for the affine layers
        out_pool_flat = out_pool.reshape(out_pool.shape[0], -1)

        # First affine layer
        out_affine1, affine_cache1 = affine_forward(out_pool_flat, W2, b2)
        out_relu2, relu_cache2 = relu_forward(out_affine1)

        # Second affine layer (output layer)
        scores, affine_cache2 = affine_forward(out_relu2, W3, b3)

        if y is None:
            return scores

        loss, dout = softmax_loss(scores, y)
        reg_loss = 0.5 * self.reg * (np.sum(W1 * W1) + np.sum(W2 * W2) + np.sum(W3 * W3))
        loss += reg_loss

        # Backpropagation
        grads = {}
        dout, grads['W3'], grads['b3'] = affine_backward(dout, affine_cache2)
        grads['W3'] += self.reg * W3
        dout = relu_backward(dout, relu_cache2)
        dout, grads['W2'], grads['b2'] = affine_backward(dout, affine_cache1)
        grads['W2'] += self.reg * W2
        
        print("Shape of dout after first affine backward:", dout.shape)  # Debug print

        # Reshape dout to match the shape before max-pooling
        N, C, H_out, W_out = out_pool.shape  # Get the shape of out_pool for dimensions
        dout = dout.reshape(N, C, H_out, W_out)  # Reshape dout to (N, C, H_out, W_out)
        
        dout = max_pool_backward_fast(dout, pool_cache)
        
        print("Shape of dout after max-pool backward:", dout.shape)  # Debug print

        dout = relu_backward(dout, relu_cache)
        dout, grads['W1'], grads['b1'] = conv_backward_fast(dout, conv_cache)
        grads['W1'] += self.reg * W1

        return loss, grads
